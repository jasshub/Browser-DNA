# 🔍 Browser Fingerprint Tracker (Stealth Version)

This project silently collects advanced browser fingerprints (Canvas, WebGL, Audio, Fonts, Plugins, etc.) and sends the data to a backend or webhook for analysis — **without notifying the user**.

## 🎯 Features
- Canvas, WebGL, Audio, Fonts, Plugins, Env fingerprinting
- SHA-256 fingerprint hash
- Incognito mode detection
- Fingerprint persistence using localStorage
- Sends data stealthily via POST
- GitHub Pages ready

## 🛠 Usage

1. Fork or clone this repo.
2. Replace `https://your-server.com/log-fingerprint` in `fingerprint.js` with your actual logging URL:
   - A webhook (e.g., https://webhook.site) or
   - Your custom API endpoint
3. Enable GitHub Pages:
   - Go to **Settings > Pages**
   - Source: `main` branch, root folder `/`
4. Access: `https://yourusername.github.io/browser-fingerprint-tracker`

## 🧪 Testing
- Open in normal and incognito windows
- Change device or browser
- Observe received logs on your server or webhook

## 📦 Output Sent to Server

```json
{
  "fingerprint": {
    "canvasHash": "...",
    "webglHash": "...",
    "audioHash": "...",
    "fontHash": "...",
    "envHash": "...",
    "pluginsHash": "...",
    "combinedFingerprint": "...",
    "canvasPreview": "data:image/png;base64,..."
  },
  "timestamp": "2025-06-14T18:30:00Z",
  "isIncognito": false,
  "sameUser": true
}
```
